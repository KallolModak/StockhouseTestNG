/*
 * @(#)POAORB.java	1.119 05/11/17
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.corba.se.internal.POA;

/** 
 * Deprecated class for backward compatibility.
 */
public class POAORB extends com.sun.corba.se.internal.iiop.ORB
{
    public POAORB( )
    {
	super();
    }
}
